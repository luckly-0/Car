#ifndef CAR_H
#define CAR_H
#include <QPair>
#include <decision.h>
#include <mainwindow.h>
#include <QObject>
#include <QQueue>
class MainWindow;
class decision;
struct QPoint3d;
class Car : QWidget
{
    Q_OBJECT
public:
    Car(MainWindow *parent,int bx,int by,int bz);
    const int M_dir[5] = {0,90,180,270,0};
    int num ;
    int ex,ey,ez,direx,dirbx,bx,by,bz,nowidz;

    int turn_state = 0; //  0 代表非转弯，1代表准备转弯，2代表开始转弯
    int turn_sign = 0 ;// 判断转弯角度的变化方向
    int turn_pre_idx,turn_pre_idy;//  如果当前下标位置与之前不同，开始转弯0 n
    double turn_velocity[10] = {10,5,8,9,6,10,2,5,5,0};
    int dieta[10] = {0,6,5,4,2,180,6,7,5,0};
    int idx,idy,idz;
    /*
      turn_cor 表示车子现在什么状态
      if cor = 0 直走
      if cor = 1 90度转弯半径为1
      if cor = 2 90度转弯半径为2
      if cor = 3 90度转弯半径为3
      if cor = 4 90度转弯半径为4
      if cor = 5 180度转弯半径为0 // 原地转弯
      if cor = 6 180度转弯半径为1
      if cor = 7 180度转弯半径为2
      if cor = 8 180度转弯半径为3
      if cor = 9 不动
    */
    int turn_cor = 0;
    int nowx,nowy,nowidx,nowidy,nowz;
    int center_idx , center_idy,Floor;
    int prex = -1,prey,predir=-1;
    int precodex = -1,precodey = -1,precodez;
    int tarx,tary;
    int sum_dir,dir1;
    int dir = -1;
    int angle ;//  小车的方向角[0,360)
    int next_point;

    MainWindow *p;
    decision *p1;

    bool if_barcode(int nowidx,int nowidy,int idz);// 遇到二维码
    void go(int ex,int ey,int ez);
    bool canturn();
    int init_dir();//初始化方向
    int task_state = 0 ; // 任务状态 ，0工作区，1要充电，2是去电梯
    QQueue<QPoint3d> task;
    void append_task(QPoint3d x);
    bool is_free();
    void update_id();
    // -----------------battery------------------//
    double remain_charge ;
    const double begin_charge = 100;
    bool check_charge();
    bool if_gocharge(QPoint3d i);
    // -----------------random（废弃）-------------------//
    int random_dir(int dir);
    const int rand = 0;
    int generateRand(int min, int max);
    //-----------------调度------------------//
    bool clog = 0;
    QVector<QPoint3d> Lock,_pre_lock;
    void update_Lock(int x,int y,int xx,int yy);
    void unLock();
    void lock();
private:
    const double power_consumption_speed = 0.02;

    bool do_task(int state); //  做任务
    void clear_queue();
};

#endif // CAR_H
