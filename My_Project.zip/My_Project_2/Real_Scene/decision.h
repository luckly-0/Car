#ifndef DECISION_H
#define DECISION_H
#include <stack>
#include <QObject>
#include <QMap>
#include <car.h>
#include <queue>
#include <mainwindow.h>
class Car;
struct QPoint3d;
// 小车智慧体保存的地图和下一步的决策，传出下一步要走的方向
class decision
{
    //Q_OBJECT
public:
    decision(Car *p = NULL);
    QVector<int> Map[2000];// 地图
    QVector<QPoint> *Point;   // 第i个点的信息
    QMap<QPair<int,int>,int> *M;      // 点信息的哈希值
    bool vis[2000];
    int tot_node = 0;
    int next_dir = 0;
    Car *p_car ;
    std::queue<int> q;
    std::queue<int> turn_q;
    std::queue<int> dir_q;
    std::queue<int> reach_point;
    QVector<int> Astart_get_path(int ix,int iy,int iz,int x,int y,int z,bool get_dis = 0);
    //QPair<int,int> get_near_barcodeid(int nowx,int nowy);
    int get_decision(int bx,int by,int bz,int dir,int ex,int ey,int ez);
    void add_edge(int idx,int idy,int idz,int idx1,int idy1,int idz1);
    QPoint3d near_charge_pos(int idx,int idy,int idz);
    bool is_left(int idx,int idy);
private:
    //int get_node_cnt(int x,int y,int z);

};

#endif // DECISION_H
