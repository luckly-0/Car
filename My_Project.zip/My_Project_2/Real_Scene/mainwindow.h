#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>
#include <car.h>
#include <QQueue>
#include <QDebug>
#include <map>
#include <queue>
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE
class Car;
class decision;
struct QPoint3d {
    int X,Y,Z;
    int x(){
        return X;
    }
    int y(){
        return Y;
    }
    int z(){
        return Z;
    }
    void print (){
        qDebug () <<"QPoint3d("<<X<<" "<<Y<<" "<<Z<<")\n";
    }
    bool operator ==(const QPoint3d a)const{
        if(X==a.X&&Y==a.Y&&Z==a.Z) return 1;
        else return 0;
    }
    bool operator < (const QPoint3d a)const {
        if(X!=a.X) return X<a.X;
        else if(Y!=a.Y) return Y <a.Y;
        else return Z < a.Z;
    }
};
struct barcode{ // 二维码的方向,第几个格子
    int x,y,z,dir;
    bool operator <(const barcode a)const {
        if(x!=a.x) return x<a.x;
        else if(y!=a.y) return y <a.y;
        else if(z!=a.z)return z < a.z;
        else return dir < a.dir;
    }
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    public:
    const int dir[4][2] = {0,-1,1,0,0,1,-1,0};//上，左，下，右
    const int barrier_size = 40;
    const int car_size = 26;
    int bx=-1,by=-1,bz=-1;
    int put_state = 0;
    bool run = 0;
    int tot_node;
    int Floor ;

    QVector<int> Map[2000];
    QVector<QPoint3d> partition ;
    QVector<QPoint3d> task;
    std :: map<QPoint3d,int> barrier;
    std :: map<barcode,int> bar;
    QVector<QPoint> t;
    QVector<QPoint3d > begin;
    QVector<QPoint3d> charge_pos;
    QVector<QPoint3d> Road;
    QVector<QPoint3d> Point;
    QVector<QPoint> Elevator;
    QPair<int,int> xy_to_id();
    QPoint get_center(int idx,int idy);
    QPair<int,int> id_to_xy(int x,int y);
    // XXXX
      public:
    //=============== XXXXX begin

    //=============== XXXX  end

    public:
    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *event);
    double distance (QPoint a,QPoint b);
    void add_edge(int idx,int idy,int idz,int idx1,int idy1,int idz1);
    int get_node_cnt(int x,int y,int z);
    void build();
    void crerate_car();
    QMap<QPoint3d,int> M;
    // ---------------------调度--------------------//
    QVector<Car *> p;
    decision * des;
    QMap<QPoint3d,int> Lock;//  锁定
    std::queue<Car *> requset; // 请求通行的车队列
    bool assign_task(Car *u); // 为u小车分配任务
    void slove_request(Car *u); // 解决第x个小车的需求
    //------------------UI--------------------//
    Ui::MainWindow *ui;
private slots:
    void clear();

    void on_pushButton_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_actionsave_triggered();

    void on_actionopen_triggered();

    void on_pushButton_8_clicked();

    void on_pushButton_9_clicked();

    void on_pushButton_10_clicked();

    void on_pushButton_11_clicked();

    void on_pushButton_12_clicked();

    void on_pushButton_13_clicked();

    void on_pushButton_14_clicked();

    void on_pushButton_15_clicked();

    void on_pushButton_16_clicked();

    void on_pushButton_17_clicked();

    void on_pushButton_18_clicked();

    void on_pushButton_19_clicked();

private:

};
#endif // MAINWINDOW_H
