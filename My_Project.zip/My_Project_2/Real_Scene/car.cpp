#include "car.h"
#include <QTime>
#include <math.h>
#include <QPair>
#include <QDebug>
#include <QTimer>
#include <complex>
#include <QQueue>
#include <cmath>

#define _USE_MATH_DEFINES
Car::Car(MainWindow *parent,int bx,int by,int bz):p(parent)
{
    int sz = p->barrier_size;
    int sz1 = p->car_size;
    this->bx = bx;
    this->by = by;
    this->bz = bz;
    nowidx = bx;
    nowidy = by;
    nowidz = idz = bz;
    nowx = bx*sz+0.5*(sz-sz1);
    nowy = by*sz+0.5*(sz-sz1);
    remain_charge =  begin_charge;
    p1 = new decision(this);
    QTimer *timer1 = new QTimer(this);
    timer1->start(50);
    ex = bx,ey = by,ez = bz;

    task.push_back({bx,by,bz});  // 初始化
    Lock.push_back({idx,idy,idz}); // 首先占据自身的格子
    connect(timer1,&QTimer::timeout,this,[=]() {
        if(parent->run == 1){
            update_id(); // 通过现在实际坐标获取当前车子的下标位置
            // 检查电池容量
            if(check_charge()&&!if_gocharge({ex,ey,ez})){
               qDebug() << "前往充电";
               task.push_front(p1->near_charge_pos(idx,idy,idz)); // 任务队列塞入最近的充电位置
               task_state = 1; // 充电状态
            }
            if(idx == ex && idy == ey &&idz == ez){ //  到达目的地
                qDebug() << "到达目的地";
                int finish = do_task(task_state); // 完成任务
                if(finish == 1&&task.size()) { // 是否完成任务
                    task.pop_front();
                    clear_queue();
                }
                if(task.size() == 0 ) {
                    p->assign_task(this);
                    if(task.size()==0){
                        unLock();
                        idz = -1;
                        // 还是没有任务分配给他时，将小车摧毁
                    }
                }
            }
            if(task.size()){
                ex = task.front().x();
                ey = task.front().y();
                ez = task.front().z();
                go(ex,ey,ez);
            }

            unLock();
        }
    });
}
void Car :: clear_queue(){
    qDebug() <<"正在清空队列\n";
    while(p1->q.size())p1->q.pop();
    while(p1->turn_q.size())p1->turn_q.pop();
    while(p1->dir_q.size())p1->dir_q.pop();
    while(p1->reach_point.size())p1->reach_point.pop();
}
int Car :: random_dir(int angle){
    return generateRand(angle-rand,angle+rand);
}
void Car :: append_task(QPoint3d x){
    task.push_back(x);
}
//生成随机数
int Car::generateRand(int min, int max)
{
    static bool seedStatus;
    if (!seedStatus)
    {
        qsrand(QTime(0, 0, 0).secsTo(QTime::currentTime()));
        seedStatus = true;
    }
    if(min>max)
    {
        double temp=min;
        min=max;
        max=temp;
    }
    double diff = fabs(max-min);
    double m1=(double)(qrand()%100)/100;
    double retval=min+m1*diff;
    return retval;
}

bool Car::if_barcode(int idx,int idy,int idz){
    int if_meet = 0;
    if(precodex == idx && precodey == idy && precodez==idz) return 0;
    // 防止碰到同一个二维码
    precodex = idx;
    precodey = idy;
    precodez = idz;
    for(int i = 1;i<=4;i++){
        if(p->bar.count({idx,idy,idz,i})){
            if_meet = 1;
            dir1 = i;
        }
    }
    return if_meet;
}
bool Car :: is_free(){
    return task.size() == 0 ;
}
void Car :: go(int ex,int ey,int ez){
        predir = dir;
       // qDebug()<<"go";
        center_idx = (nowx+13)/p->barrier_size,center_idy = (nowy+13)/p->barrier_size;
        //dir = init_dir();
        if(center_idx == ex &&center_idy == ey&&idz == ez) return ;
        if(clog == 1) {
            p->slove_request(this);// 等待Mainwindow 的调度解锁clog否则将静止
            if(clog == 0) unLock(),lock(); // 可以上锁
            if(clog)return ; // 阻塞中
        }
        if( turn_cor > 0 && canturn()){ // 转弯调整角度
            angle += turn_sign*dieta[turn_cor] ;
            if(sum_dir - dieta[turn_cor] <= 0 ) sum_dir = 0 ,turn_cor=0;
            else {
                sum_dir -= dieta[turn_cor];
            }
            angle = (angle%360 + 360) %360;
        }
        else if(if_barcode(center_idx,center_idy,idz)){ // 传入中心的下标，转弯时禁止扫描二维码
            qDebug() <<"有二维码"<<center_idx<<" "<<center_idy<<" "<<idz<<" "<<dir <<"->"<<p->M[{center_idx,center_idy,idz}]<< "\n";
            if(center_idx == ex &&center_idy == ey&&idz == ez) return ;
            dir = p1->get_decision(center_idx,center_idy,idz,dir1,ex,ey,ez); // 传入中心坐标
            qDebug()<<"现在方向是"<<dir<<'\n';
            // -- 阻塞 -- //
            qDebug()<<"next_point"<<next_point<<'\n';
            _pre_lock = Lock;
            update_Lock(idx,idy,p->Point[next_point].x(),p->Point[next_point].y());// 上锁
            p->slove_request(this);// 等待Mainwindow 的调度解锁clog否则将静止
            if(clog == 0) unLock(),lock(); // 可以上锁
            // -- 阻塞 -- //
            int offect = 0;
            int cor_angle ;
            // 这里看是转弯还是直道
            qDebug() << "turn_cor" << turn_cor ;
            if(turn_cor ==0) cor_angle = M_dir[dir]; // 直道
            else if(predir != dir&&turn_cor){
//                    turn_pre_idx = center_idx ;
//                    turn_pre_idy = center_idy ;
                if(predir == -1) predir = dir1,angle = M_dir[dir1];
                if(dir==((predir+1)!=5?predir+1:1))turn_sign = 1;
                else turn_sign = -1;
                int k = M_dir[predir]+turn_sign*90;
                if(k<0) k+=360;
                cor_angle = M_dir[predir]; // 保持原有方向
                sum_dir = k - angle;
                if(sum_dir<0) sum_dir = -sum_dir;
                sum_dir = (sum_dir%180+180)%180;
                sum_dir += ((turn_cor>=5)?90:0); // 如果是急转弯旋转角度是180度
                qDebug() << sum_dir<<"总角度\n";
            } // 进入准备转弯
            offect = cor_angle - angle;
            angle = random_dir(cor_angle + 0); // +offect
            angle = (angle%360 + 360) %360;
           // qDebug()<<"角度"<<angle<< '\n';
         }
        else if(p->barrier.count({center_idx,center_idy,idz})){
                p->run = 0;
            }
         nowx = round(nowx+cos(angle*M_PI/180)*turn_velocity[turn_cor]);
         nowy = round(nowy-sin(angle*M_PI/180)*turn_velocity[turn_cor]);

         int walk = sqrt(cos(angle*M_PI/180)*turn_velocity[turn_cor]*cos(angle*M_PI/180)*turn_velocity[turn_cor]+
                sin(angle*M_PI/180)*turn_velocity[turn_cor]*sin(angle*M_PI/180)*turn_velocity[turn_cor]);

         remain_charge -= power_consumption_speed*walk; //消耗电量

         p->update();

}
void Car :: unLock(){
    for(auto i : _pre_lock){
        p->Lock[i] = 0;
    }
}
int Car ::init_dir(){
    for(int i = 1;i<=4;i++){
        if(p->bar[{center_idx,center_idy,idz,i}] == 1) {
           if(i==2) return 3;
           else if(i==3) return 2;
           else return i;
        }
    }

}
void Car :: lock(){
    for(auto i : Lock){
        //p->Lock[i] = 1;
    }
}
void Car :: update_Lock(int x,int y,int xx,int yy){
   // unLock();
    Lock.clear();
    p->requset.push(this);
    qDebug() <<"锁定"<< x<< " " << y<<" "<<xx<<" "<<yy;
    for(int i = std::min(x,xx);i<=std::max(x,xx);i++){
        for(int j = std::min(y,yy);j<=std::max(y,yy);j++){
            if(i == x && j == y) continue;
            Lock.push_back({i,j,idz});
        }
    }
    clog = 1;
}
bool Car :: check_charge(){
    return remain_charge <= 30;
}
bool Car ::if_gocharge(QPoint3d x){
    for(QPoint3d i : p->charge_pos){
        if(i == x) return 1;
    }
    return 0;
}
bool Car ::do_task(int state){//  做任务
    if(state == 0) return 1;
    else if(state == 1){
        qDebug() << "正在充电 ";
        remain_charge += 5;
        p->update();
        if(remain_charge >= 100) {
            remain_charge = 100;
            task_state = 0;
            return 1;
        }
        return 0;
    }
}
bool Car :: canturn(){
    if(turn_cor >= 6 ){ // 急转弯向前一格再转弯
        if(center_idx==precodex&&center_idy==precodey)
            return 0;
        else return 1;
    }
    return 1;
}
void Car :: update_id(){
    idx = (nowx+13)/p->barrier_size,idy = (nowy+13)/p->barrier_size;
}
