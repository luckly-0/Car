#include "decision.h"
#include <queue>
#include <math.h>
#include <complex>
#include <QtDebug>
#include <QPoint>
#include <car.h>
#include <cmath>
decision::decision(Car *p)
{
    p_car = p;
    next_dir = 0;
}
QVector<int> decision::Astart_get_path(int ix,int iy,int iz,int x,int y,int z,bool get_dis ){
    int end = p_car->p->M[{x,y,z}];
    int begin = p_car->p->M[{ix,iy,iz}];
    qDebug() <<begin << " " <<end<<"A*起点终点\n";
    QVector<int> open(3000,0),close(3000,0),dist(3000,0x3f3f3f3f),H(3000,0x3f3f3f3f),fa(3000,0);
    std::priority_queue<QPair<double,int>> Q;
    Q.push({0,begin});
    dist[begin] = 0;
    while(!Q.empty()){
        int u = Q.top().second;
        if(u == end ) break;
        close[u] = 1;
        Q.pop();
        for(int i : p_car->p->Map[u]){
            if(close[i]) continue;
            double g = sqrt((p_car->p->Point[i].x()-p_car->p->Point[u].x())*(p_car->p->Point[i].x()-p_car->p->Point[u].x())+(p_car->p->Point[i].y()-p_car->p->Point[u].y())*(p_car->p->Point[i].y()-p_car->p->Point[u].y())+(p_car->p->Point[i].z()-p_car->p->Point[u].z())*(p_car->p->Point[i].z()-p_car->p->Point[u].z()));
            H[i] = sqrt((p_car->p->Point[i].x()-p_car->p->Point[u].x())*(p_car->p->Point[i].x()-p_car->p->Point[u].x())+(p_car->p->Point[i].y()-p_car->p->Point[u].y())*(p_car->p->Point[i].y()-p_car->p->Point[u].y())+(p_car->p->Point[i].z()-p_car->p->Point[u].z())*(p_car->p->Point[i].z()-p_car->p->Point[u].z()));
            if(!open[i]||dist[i] > dist[u] + g) {
                dist[i] = dist[u] + g;
                open[i] = 1;
                Q.push({-dist[i]-H[i],i});
                fa[i] = u;
            }
        }
    }
    int now = end;
    QVector<int> Path;
    if(get_dis == 1) return {dist[end]};
    if(dist[end] < 0x3f3f3f3f) {
        while(1){
            Path.push_back(now);
            if(now == begin) break;
            now = fa[now];
        }
    }
    else qDebug() <<"没路\n";
    QVector<int> t(Path.rbegin(),Path.rend());
    qDebug() << "A*" <<'\n';
    for(int i : t){
        qDebug() << i <<'\n';
    }
    return t;
}
int decision::get_decision(int bx,int by,int bz,int dir1,int ex,int ey,int ez){
    int carix = p_car->p->M[{bx,by,bz}];

    if(is_left(bx,by)) {
        p_car->idz = ez;
        qDebug() << "到达电梯" << ez ;
    }
    int ix,dir;
    if(q.size()){
        ix = q.front();
        dir = dir_q.front();
        //发现栈顶坐标不是当前位置，表示需要规划
        p_car->turn_cor = turn_q.front();
        p_car->next_point = reach_point.front();
        reach_point.pop();
        turn_q.pop();
        q.pop();
        dir_q.pop();
    }
    qDebug() << carix << " " << ix<<"\n";
    if(q.size()==0||carix != ix){
        qDebug() <<"正在清空队列\n";
        while(q.size())q.pop();
        turn_q = q;
        dir_q = q;
        reach_point = q;
        qDebug() <<"发现栈顶坐标不是当前位置，表示需要规划\n";
        qDebug() <<ex<<" "<<ey<<'\n';
        QVector <int> Path = Astart_get_path(bx,by,bz,ex,ey,ez);
        qDebug() << "规划路线为" ;
        for(int i = 1;i<Path.size();i++){
            reach_point.push(Path[i]);
        }
        int predir = p_car->init_dir();
        qDebug() <<"decision predir" << predir;
        for(int i = 1;i<Path.size();i++){
            int ndir ;
            int turn = 0;
            int x = Path[i-1],y = Path[i];
            QPoint3d a1 = p_car->p->Point[x],a2 = p_car->p->Point[y];

            if(q.size())predir = dir_q.back();

            if(a2.y()<a1.y()&&a1.x()==a2.x()) ndir = 1;
            if(a2.y()>a1.y()&&a1.x()==a2.x()) ndir = 3;
            if(a1.x()<a2.x()&&a1.y()==a2.y()) ndir = 4;
            if(a1.x()>a2.x()&&a1.y()==a2.y()) ndir = 2;
            if(a1.x()!=a2.x()&&a1.y()!=a2.y()) {
                if(predir == 1){
                    if(a1.x()<a2.x()) ndir = 4;
                    else ndir = 2;
                    turn = abs(a1.y()-a2.y());
                }
                else if(predir == 3){
                    if(a1.x()<a2.x()) ndir = 4;
                    else ndir = 2;
                    turn = abs(a1.y()-a2.y());
                }
                else if(predir== 2){
                    if(a1.y()>a2.y())ndir = 1;
                    else ndir = 3;
                    turn = abs(a1.x()-a2.x());
                }
                else {
                    if(a1.y()>a2.y())ndir = 1;
                    else ndir = 3;
                    turn = abs(a1.x()-a2.x());
                }
            }
            else if(ndir!=predir&&(i==1||turn_q.size()!=0&&turn_q.back()<5)){
                qDebug() << "急转弯";
                if(predir == 2){
                    turn = abs(a1.y()-a2.y()) + 5;
                }
                else if(predir == 4){
                    turn = abs(a1.y()-a2.y())+ 5;
                }
                else if(predir== 3){
                    turn = abs(a1.x()-a2.x())+ 5;
                }
                else {
                    turn = abs(a1.x()-a2.x()) + 5 ;
                }
            }
            qDebug() <<ndir<< '~'<<turn<<" ";
            q.push(Path[i]);
            turn_q.push(turn);
            dir_q.push(ndir);
        }
        p_car->turn_cor = turn_q.front();
        p_car->next_point = reach_point.front();
        dir = dir_q.front();
        dir_q.pop();
        reach_point.pop();
        turn_q.pop();
    }
    return dir;
}
QPoint3d decision ::  near_charge_pos(int idx,int idy,int idz){
    QPoint3d ans ;
    int minn = 0x3f3f3f3f;
    for(QPoint3d i : p_car->p->charge_pos){
        int x = i.x(),y = i.y(),z = i.z();
        QVector<int> t = Astart_get_path(idx,idy,idz,x,y,z,1);
        if(t[0]<minn) {
            minn = t[0];
            ans = i;
        }
    }
    return ans;
}
bool decision :: is_left(int idx,int idy){
    QPoint find = {idx,idy};
    for(QPoint i : p_car->p->Elevator){
        if(i == find) return 1;
    }
    return 0;
}
