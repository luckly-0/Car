#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QMouseEvent>
#include <QFileDialog>
#include <QTextStream>
#include <QDebug>
#include <QtMath>
#include <math.h>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    resize(1000,1000);
    ui->textEdit_2->setText("当前层数:" + QString::number(Floor));
}
MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::paintEvent(QPaintEvent *){
    int height = this->height(),weight = this->width();
    QPainter painter(this);
    QPixmap car_png(":/new/prefix1/resource/car.png");
    QPixmap png_barrier(":/new/prefix1/resource/barrier.png");
    QPixmap bar_png_up(":/new/prefix1/resource/up.png");
    QPixmap bar_png_down(":/new/prefix1/resource/down.png");
    QPixmap bar_png_lert(":/new/prefix1/resource/left.png");
    QPixmap bar_png_right(":/new/prefix1/resource/right.png");
    QPixmap charge_positon(":/new/prefix1/resource/charge_position.png");
    QPixmap bar_png[5] = {bar_png_up,bar_png_up,bar_png_down,bar_png_lert,bar_png_right};
    QPixmap begin_png(":/new/prefix1/resource/begin.png");
    QPixmap end_png(":/new/prefix1/resource/end.png") ;
    QPixmap Elevator_png(":/new/prefix1/resource/elevator.png");
    for(QPoint p : Elevator) {
        int i = p.x(),j = p.y();
        QRect q = {i*barrier_size,j*barrier_size,barrier_size,barrier_size};
        painter.drawPixmap(q,Elevator_png);
    }
    for(auto pp : barrier){
        if(pp.second == 0) continue;
        QPoint3d  p = pp.first;
        int i = p.x(),j = p.y(),z = p.z();
        if(z != Floor) continue;
        QRect q = {i*barrier_size,j*barrier_size,barrier_size,barrier_size};
        painter.drawPixmap(q,png_barrier);
    }

    for(auto pp : bar){
        if(pp.second == 0) continue;
        barcode p = pp.first;
        int i = p.x,j = p.y,z = p.z,k = p.dir;
        if(z != Floor) continue;
        QRect q = {i*barrier_size,j*barrier_size,barrier_size,barrier_size};
          painter.drawPixmap(q,bar_png[k]);
    }
    for(QPoint3d i : begin){
        int bx = i.x(),by = i.y(),bz = i.z();
        if(bz == Floor){
            QRect pp = {bx*barrier_size,by*barrier_size,barrier_size,barrier_size};
            painter.drawPixmap(pp,begin_png);
        }
    }
    for(QPoint3d i : task){
        int ex = i.x(), ey = i.y(),ez = i.z();
        if(ez != Floor) continue;
        QRect p1 = {ex*barrier_size,ey*barrier_size,barrier_size,barrier_size};
        painter.drawPixmap(p1,end_png);
    }
    if(run){
        ui->textEdit_3->setText(QString::number(p[0]->num));
        QString bt ="电量:\n";
        for(int i = 0 ; i < begin.size() ; i++){
            int f = p[i]->idz;
            if( f == Floor){
                QRect p2 = {p[i]->nowx,p[i]->nowy,car_size,car_size};
                painter.drawPixmap(p2,car_png);
            }
            bt += QString :: number(p[i]->remain_charge);
            bt += "\n";
        }
        ui->textEdit->setText(bt);
    }
    painter.setPen(Qt::red);
//    for(int i = 0;i<partition.size();i+=2){
//        painter.drawLine(partition[i],partition[i+1]);
//    }
    painter.setPen(Qt::green);
    for(int i = 0;i+1<Road.size();i+=2){
        QPoint3d a1 = Road[i] , a2 = Road[i+1];
        if(a1.z()!=Floor) continue;
        QPoint p1 = get_center(a1.x(),a1.y());
        QPoint p2 = get_center(a2.x(),a2.y());
        painter.drawLine(p1,p2);
    }
    for(QPoint3d i : charge_pos){
        if(i.z()!=Floor) continue;
        QRect ii = {i.x()*barrier_size,i.y()*barrier_size,barrier_size,barrier_size};
        painter.drawPixmap(ii,charge_positon);
    }

}
void MainWindow :: mousePressEvent(QMouseEvent *event){
    QPoint pos = event->pos();
    int idx = pos.x()/barrier_size;
    int idy = pos.y()/barrier_size;
    if(put_state == 7){
        QPoint cen = pos;
        QPoint q1 = {idx * barrier_size,idy * barrier_size};
        QPoint q2 = {idx * barrier_size+barrier_size,idy * barrier_size};
        QPoint q3 = {idx * barrier_size,idy * barrier_size+barrier_size};
        QPoint q4 = {idx * barrier_size+barrier_size,idy * barrier_size+barrier_size};
        QPoint q12 = {idx * barrier_size+barrier_size/2,idy * barrier_size};
        QPoint q24 = {idx * barrier_size+barrier_size,idy * barrier_size/2};
        QPoint q13 = {idx * barrier_size,idy * barrier_size+barrier_size/2};
        QPoint q34 = {idx * barrier_size+barrier_size/2,idy * barrier_size+barrier_size};
        int d1 = distance(cen,q12);
        int d2 = distance(cen,q24);
        int d3 = distance(cen,q13);
        int d4 = distance(cen,q34);
        qDebug() << d1<<" "<<d2<<" "<<d3<<" "<<d4<<" "<<q12<<" "<<q24<<" "<<q13<<" "<<q34<<'\n';
        QPoint w1,w2 ;
        if(d1<=d2&&d1<=d3&&d1<=d4) w1 = q1,w2 = q2;
        else if(d2<=d1&&d2<=d3&&d2<=d4) w1 = q2,w2 = q4;
        else if(d3<=d2&&d3<=d1&&d3<=d4) w1 = q1,w2 = q3;
        else if(d4<=d2&&d4<=d3&&d4<=d1) w1 = q3,w2 = q4;
//        int ok = 0;
//        for(int i = 0;i+1<partition.size();i++){
//            if(partition[i]==w1&&partition[i+1]==w2) {
//                ok = 1;
//                partition.erase(partition.begin()+i,partition.begin()+i+2);
//            }
//        }
//        if(!ok) partition.push_back(w1),partition.push_back(w2);
//        for(int i = 0;i+1<partition.size();i++){qDebug() << partition[i]<<" ";}
    }
    else if(put_state == 6){
        if(barrier.count({idx,idy,Floor})) barrier.erase({idx,idy,Floor});
        else barrier[{idx,idy,Floor}] = 1;
    }
    else if(put_state <= 3){
        if(bar.count({idx,idy,Floor,put_state+1})) bar.erase({idx,idy,Floor,put_state+1});
        else bar[{idx,idy,Floor,put_state+1}] = 1;

       // bar[idx][idy][put_state+1][Floor] ^= 1;
    }
    else if(put_state == 4) {
        int find = 0;
        QPoint3d want ={idx,idy,Floor};
        for(int i = 0;i<begin.size();i++){
            if(want == begin[i]) begin.erase(begin.begin() + i),find = 1;
        }
        if(find == 0)begin.push_back(want);
    }
    else if(put_state == 5)task.push_back({idx,idy,Floor});
    else if(put_state == 8){
        t.push_back({idx,idy});
        Road.push_back({idx,idy,Floor});
        if(t.size() == 2) {
            t.clear();
        }
    }
    else if(put_state == 9){
        charge_pos.push_back({idx,idy,Floor});
    }
    else if(put_state == 10){
        Elevator.push_back({idx,idy});
    }
    update();
}
QPair <int,int> MainWindow::id_to_xy(int x,int y){
    return {x*barrier_size,y*barrier_size};
}
QPoint MainWindow::get_center(int idx,int idy){
    return {idx*barrier_size+barrier_size/2,idy*barrier_size+barrier_size/2};
}
double MainWindow::distance (QPoint a,QPoint b){
    return sqrt((a.x()-b.x())*(a.x()-b.x())+(a.y()-b.y())*(a.y()-b.y()));
}
void MainWindow::on_pushButton_clicked()
{
    put_state = 0;
}

void MainWindow::on_pushButton_6_clicked()
{
    put_state = 2;
}

void MainWindow::on_pushButton_5_clicked()
{
    put_state = 1;
}

void MainWindow::on_pushButton_7_clicked()
{
    put_state = 3;
}

void MainWindow::on_pushButton_2_clicked()
{
    put_state = 4;
}

void MainWindow::on_pushButton_3_clicked()
{
    put_state = 5;
}

void MainWindow::on_pushButton_4_clicked()
{
    put_state = 6;
}
void MainWindow::on_actionsave_triggered(){
    QString file_path = QFileDialog :: getSaveFileName(this,"保存文件","../file/");
    QFile file(file_path);
    if(file.exists()){
    file.open(QIODevice::WriteOnly);
    QTextStream out(&file);
    out << barrier.size() << ' ';
    for(auto pp : barrier){
        if(pp.second == 0) continue;
        QPoint3d  p = pp.first;
        int i = p.x(),j = p.y(),z = p.z();
        out << i <<" " << j << " " << z <<" ";
    }
    out << bar.size() << ' ';
    for(auto pp : bar){
        if(pp.second == 0) continue;
        barcode p = pp.first;
        int i = p.x,j = p.y,z = p.z,k = p.dir;
        out << i <<" " << j << " " << z <<" " << k <<" ";
    }
    out << begin.size()<<" ";
    for(QPoint3d i : begin){
        out << i.x()<<" "<<i.y()<<" "<<i.z()<<" ";
    }
    out << task.size() << " "<< '\n';
    for(QPoint3d i : task){
        out << i.x()<<" "<<i.y()<<" "<<i.z()<<" ";
    }
    out << partition.size()<< " ";
    for(QPoint3d i : partition){
        out << i.x()<< " " <<i.y()<<" "<<i.z()<<" ";
    }
    out << Road.size() << " ";
    for(QPoint3d i : Road){
        out << i.x() <<" "<< i.y()<<" "<<i.z()<<" ";
    }
    out << charge_pos.size() <<" ";
    for(QPoint3d i : charge_pos){
        out << i.x() <<" "<< i.y()<<" "<<i.z()<<" ";
    }
    out << Elevator.size() << " ";
    for(QPoint i : Elevator){
        out << i.x() <<" "<< i.y()<<" ";
    }
    file.close();
    }
}
void MainWindow::on_actionopen_triggered(){
    QString file_path = QFileDialog :: getOpenFileName(this,"打开文件","../file/");
    if(file_path.isEmpty() == 1) return ;
    QFile file(file_path);
    file.open(QIODevice::ReadOnly);
    QTextStream in(&file);//将文件绑定到流对象上
    clear();
    int n ;
    in >> n;
    for(int i = 0;i<n;i++){
        int a,b,c;
        in>>a>>b>>c;
        barrier[{a,b,c}] = 1;
    }
    in >> n;
    for(int i = 0;i<n;i++){
        int a,b,c,d;
        in >> a >> b>> c>> d;
        bar[{a,b,c,d}] = 1;
    }
    in >> n;
    for(int i = 0;i<n;i++){
        int a,b,F;
        in >> a >> b >> F;
        begin.push_back({a,b,F});
    }
    in >> n;
    for(int i = 0;i<n;i++){
        int a,b,F;
        in >> a >> b >> F;
        task.push_back({a,b,F});
    }
    in >> n;
    for(int i = 0;i<n;i++){
        int a,b,F;
        in >> a >> b >> F;
        partition.push_back({a,b,F});
    }
    in >> n ;
    for(int i = 0;i<n;i++){
        int a,b,F;
        in >> a >> b >> F;
        Road.push_back({a,b,F});
    }
    in >> n ;
    for(int i = 0;i<n;i++){
        int a,b,F;
        in >> a >> b >> F;
        charge_pos.push_back({a,b,F});
    }
    in >> n ;
    for(int i = 0;i<n;i++){
        int a,b;
        in >> a >> b;
        Elevator.push_back({a,b});
    }
    update();
}
void MainWindow::on_pushButton_8_clicked()
{
    run ^= 1;
    if(run==0)ui->pushButton_8->setText("运行");
    else ui->pushButton_8->setText("暂停"),crerate_car();
    update();
}
void MainWindow::on_pushButton_9_clicked()
{
    put_state = 7;
}

void MainWindow::on_pushButton_10_clicked()
{
    if(partition.size())
       partition.pop_back();
    if(partition.size())
       partition.pop_back();
    update();
}
void MainWindow::on_pushButton_11_clicked()
{
    put_state = 8;
}
int MainWindow:: get_node_cnt(int x,int y,int z){
    if(M.count({x,y,z})==0) {
        M[{x,y,z}] =tot_node;
        Point.push_back({x,y,z});
         ++tot_node;
    }
    return M[{x,y,z}];
}
void MainWindow::add_edge(int idx,int idy,int idz,int idx1,int idy1,int idz1){
    int a = get_node_cnt(idx,idy,idz);
    int b = get_node_cnt(idx1,idy1,idz1);
    Map[a].push_back(b);
}
void MainWindow::build(){
   qDebug() << "正在建图";
   for(int i = 0 ;i<1999;i++) Map[i].clear();
   Point.clear();
   M.clear();

   for(int i = 0;i<Road.size();i+=2){
        QPoint3d a = Road[i],b = Road[i+1];
        a.print();
        b.print();
        add_edge(a.x(),a.y(),a.z(),b.x(),b.y(),b.z());
   }
   //  ---------- 电梯连线 ---------//
   for(QPoint i : Elevator){
       for(int j = 1;j<=3;j++){
           add_edge(i.x(),i.y(),j,i.x(),i.y(),j-1);
           add_edge(i.x(),i.y(),j-1,i.x(),i.y(),j);
       }
   }
}
void MainWindow :: crerate_car(){
    qDebug() << "创建小车中" ;
    build();

    for(int i = 0;i<begin.size();i++){
        p.push_back(new Car(this,begin[i].x(),begin[i].y(),begin[i].z()));
    }
    qDebug() << "成功创建小车" ;
}
void MainWindow :: slove_request(Car * u){
    int ok = 1;
    for(auto i : u->Lock){
        if(Lock[i] == 1) {
            ok = 0;
        }
    }
    if(ok == 1)u->clog = 0;
}
bool MainWindow :: assign_task(Car * cp){
    // 分配任务遵循最近空闲原则
    QVector<QPoint3d> task_remain ;
    int k = 0;
    //qDebug()<<"p"<< p.size()<<" "<<task.size();
    int minn = 0x3f3f3f3f;
    QPoint3d ass;
    for(QPoint3d i : task){
        int x = i.x(),y = i.y(),z = i.z();
        int xx = cp->idx;
        int yy = cp->idy;
        int zz = cp->idz;
        int dis = cp->p1->Astart_get_path(xx,yy,zz,x,y,z,1)[0];
        if(minn > dis){
            minn = dis  ;
            ass = i;
        }
    }
    if(minn != 0x3f3f3f3f)cp->append_task(ass),task.removeOne(ass);
//    else task_remain.push_back(ass);
//    task = task_remain;
}
void MainWindow::on_pushButton_12_clicked()
{
    if(Road.size()) Road.pop_back();
    if(Road.size()) Road.pop_back();
    update();
}

void MainWindow::on_pushButton_14_clicked()
{
    put_state = 9;
}

void MainWindow::on_pushButton_13_clicked()
{
    if(task.size()) task.pop_back();
    update();
}

void MainWindow::on_pushButton_15_clicked()
{
    if(charge_pos.size())charge_pos.pop_back();
    update();
}
void MainWindow :: clear(){
    task.clear();
    partition.clear();
    charge_pos.clear();
    Road.clear();
    barrier.clear();
    bar.clear();
    Elevator.clear();
    Lock.clear();
    p.clear();
    M.clear();
    begin.clear();
    while (requset.size()) {
        requset.pop();
    }
}

void MainWindow::on_pushButton_17_clicked()
{
    if(Floor>=1)Floor -- ;
    ui->textEdit_2->setText("当前层数:" + QString::number(Floor));
    update();
}

void MainWindow::on_pushButton_16_clicked()
{
    if(Floor<=2)Floor ++ ;
    ui->textEdit_2->setText("当前层数:" + QString::number(Floor));
    update();
}

void MainWindow::on_pushButton_18_clicked()
{
    put_state = 10;
}

void MainWindow::on_pushButton_19_clicked()
{
    if(Elevator.size()) Elevator.pop_back();
    update();
}
